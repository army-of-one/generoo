package {{group_id}}.{{artifact_id_periods}}.api;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class {{artifact_id_capitalized}}Controller {

}
