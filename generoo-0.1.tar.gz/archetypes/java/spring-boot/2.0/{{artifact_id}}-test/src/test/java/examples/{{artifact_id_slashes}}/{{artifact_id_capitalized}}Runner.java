package examples.{{artifact_id_periods}};

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class {{artifact_id_capitalized}}Runner {

}